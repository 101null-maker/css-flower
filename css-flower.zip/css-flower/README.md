# CSS Flower

A flower drawn with pure HTML and CSS. No JavaScript, no images.

## Run it
Open `index.html` in any browser.

## Features
- Eight petals built from one shape, rotated with a CSS variable
- Slowly rotating bloom and a swaying stem
- Respects `prefers-reduced-motion`
